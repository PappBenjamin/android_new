export enum ScheduleType {
  CUSTOM = 'custom',
  RECURRING = 'recurring',
}