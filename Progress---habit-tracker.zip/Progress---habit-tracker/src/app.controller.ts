import { Controller, Get } from '@nestjs/common';
import { AppService } from './app.service';
import { Public } from './auth/common/decorators';
import { Throttle } from '@nestjs/throttler';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) { }

  @Public()
  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Public()
  @Get('health')
  getHealth() {
    return { status: 'ok' };
  }
}
