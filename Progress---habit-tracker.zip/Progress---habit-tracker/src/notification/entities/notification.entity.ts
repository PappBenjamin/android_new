export class Notification {}
